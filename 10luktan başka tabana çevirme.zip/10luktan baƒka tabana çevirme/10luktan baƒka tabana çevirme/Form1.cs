﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
        public partial class Form1 : Form
        {
            public Form1()
            {
                InitializeComponent();
            }

            private void button1_Click(object sender, EventArgs e)
            {
                long x;
                int n;
                try
                {
                    x = int.Parse(textBox1.Text);
                    n = int.Parse(textBox2.Text);
                    label3.Text = n.ToString() + " tabanında " + x.ToString() + " =";
                    label4.Text = tabançevir(x, n);
                }
                catch
                {
                    MessageBox.Show("Sayı hatalı");
                }

            }
            string tabançevir(long x, int n)
            {
                //2 den küçük taban olamaz
                if (n < 2)
                    return "-1";
                long b;
                string s = "";
                while (x >= n)
                {
                    b = x % n; //n'e bölümünde kalan
                    x = x / n; //n'e tam böl
                    if (b > 9)
                        s = (char)(55 + b) + s;
                    else
                        s = b + s;
                }
                if (x > 9)
                    s = (char)(55 + x) + s;
                else
                    s = x + s;
                return s;
            }

            private void label3_Click(object sender, EventArgs e)
            {

            }

        }
    }
